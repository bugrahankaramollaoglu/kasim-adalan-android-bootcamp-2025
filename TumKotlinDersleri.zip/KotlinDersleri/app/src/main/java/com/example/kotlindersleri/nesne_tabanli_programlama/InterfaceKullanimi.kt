package com.example.kotlindersleri.nesne_tabanli_programlama

fun main() {
    val b = ClassB()

    println(b.degisken)

    b.metod1()

    println(b.metod2())
}