package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim

open class Hayvan {
    open fun sesCikar(){
        println("Ses Çıkar")
    }
}