package com.example.kotlindersleri.degiskenler

fun main() {
    var sehir = "Bursa"
    println("Şehir : $sehir")
}