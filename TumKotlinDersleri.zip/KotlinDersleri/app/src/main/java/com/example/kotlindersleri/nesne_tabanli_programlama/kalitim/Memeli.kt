package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim

open class Memeli : Hayvan() {

}