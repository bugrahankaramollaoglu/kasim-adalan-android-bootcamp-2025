package com.example.kotlindersleri.nesne_tabanli_programlama

//Swift dilinde Protocol
interface MyInterface {
    var degisken:Int

    fun metod1()

    fun metod2() : String
}