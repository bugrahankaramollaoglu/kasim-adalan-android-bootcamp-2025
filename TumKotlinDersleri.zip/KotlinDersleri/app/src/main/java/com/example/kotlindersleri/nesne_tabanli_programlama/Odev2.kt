package com.example.kotlindersleri.nesne_tabanli_programlama

class Odev2 {
    fun soru1(x:Double) : Double {
        return 0.0
    }
}