package com.example.kotlindersleri.nesne_tabanli_programlama




fun main() {
    val o2 = Odev2()
    val arrayList = ArrayList<String>()
}