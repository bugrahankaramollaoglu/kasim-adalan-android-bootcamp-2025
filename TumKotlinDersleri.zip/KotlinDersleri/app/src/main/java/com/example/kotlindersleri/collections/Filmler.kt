package com.example.kotlindersleri.collections

data class Filmler(var id:Int,var ad:String,var fiyat:Int) {
}