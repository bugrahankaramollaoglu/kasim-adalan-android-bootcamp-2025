package com.example.kotlindersleri.nesne_tabanli_programlama.kalitim

class Kopek : Memeli() {
    override fun sesCikar() {
        println("Hav Hav")
    }
}