package com.example.kotlindersleri.nesne_tabanli_programlama

class ClassA {
    //static
    companion object {
        var x = 10

        fun metod(){
            println("Metod çalıştı")
        }
    }

}